
<div class="col-lg-4 col-md-4 d-sm-none d-md-block d-none " style="margin-top: 20px;">
<div class="card">
  <div class="card-header">
    <h4 class="display-4 authorName"  style="font-size:30px;">Activity</h4>
  </div>
  <div class="card-body">
    <div class="postContent">    
        <p class="card-text"> Activity </p>
    </div>

  </div>
</div>
</div>