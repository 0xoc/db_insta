<div class="alert alert-success" role="alert" style="width:100%; margin:20px;">
  <strong>Loged out!</strong> You successfully loged out.
</div>